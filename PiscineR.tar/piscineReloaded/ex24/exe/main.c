#include "../includes/lib.h"
#include <unistd.h>
#include <stdio.h>

int main()
{
    ft_putstr("ZEZE");
    ft_putchar('\n');
    printf("%d\n", ft_strcmp("ZEZE","ZAZA"));
    printf("%d\n", ft_strlen("abcde"));
}