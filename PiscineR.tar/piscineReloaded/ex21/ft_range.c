/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_range.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: judenis <judenis@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/11/03 14:32:07 by judenis           #+#    #+#             */
/*   Updated: 2023/11/03 14:32:21 by judenis          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <stdlib.h>

int	*ft_range(int min, int max)
{
	int	*tab;
	int	i;
	int	j;
	int	len;

	len = (max - min);
	tab = (int *)malloc(sizeof(int) * (len));
	i = min;
	j = 0;
	if (min >= max)
		return (0);
	while (j != len)
	{
		tab[j] = i;
		i++;
		j++;
	}
	return (tab);
}

/*int main()
{
    ft_range(2, 4);
}*/