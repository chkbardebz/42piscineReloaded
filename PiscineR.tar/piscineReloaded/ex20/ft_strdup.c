/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strdup.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: judenis <judenis@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/10/31 14:39:29 by judenis           #+#    #+#             */
/*   Updated: 2023/11/03 14:30:59 by judenis          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <stdlib.h>

int	ft_strlen(char *str)
{
	int	i;

	i = 0;
	while (str[i])
	{
		i++;
	}
	return (i);
}

char	*ft_strdup(char *src)
{
	int		i;
	int		len;
	char	*tab;

	i = 0;
	len = ft_strlen(src);
	tab = (char *)malloc((len) * sizeof(char));
	while (src[i])
	{
		tab[i] = src[i];
		i++;
	}
	return (tab);
}

/*int main()
{
    printf("%s",ft_strdup("CROTTE"));
}*/