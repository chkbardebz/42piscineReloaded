/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sort_params.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: judenis <judenis@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/11/03 14:30:19 by judenis           #+#    #+#             */
/*   Updated: 2023/11/03 14:30:38 by judenis          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

int	ft_strcmp(char *s1, char *s2)
{
	int	i;

	i = 0;
	while (s1[i] != '\0' && s2[i] != '\0' && s1[i] == s2[i])
		i++;
	return (s1[i] - s2[i]);
}

void	ft_ligne(char *argv)
{
	int	i;

	i = 0;
	while (argv[i])
	{
		ft_putchar(argv[i]);
		i++;
	}
	ft_putchar('\n');
}

int	main(int argc, char **argv)
{
	int		j;
	int		k;
	char	*tmp;

	(void)argc;
	j = 1;
	k = 1;
	while (argv[j])
	{
		while (argv[k + 1])
		{
			if (ft_strcmp(argv[k], argv[k + 1]) >= 1)
			{
				tmp = argv[k];
				argv[k] = argv[k + 1];
				argv[k + 1] = tmp;
				k = 0;
			}
			k++;
		}
		ft_ligne(argv[j]);
		j++;
	}
}
