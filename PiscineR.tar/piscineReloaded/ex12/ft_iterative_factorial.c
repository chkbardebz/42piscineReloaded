/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_iterative_factorial.c                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: judenis <judenis@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/10/30 16:10:19 by judenis           #+#    #+#             */
/*   Updated: 2023/11/03 15:21:01 by judenis          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_iterative_factorial(int nb)
{
	int	resultat;

	resultat = 1;
	while (nb > 0)
	{
		resultat *= nb;
		nb--;
	}
	if (nb < 0)
		return (0);
	return (resultat);
}

/*int main()
{
	#include <stdio.h>
	printf("%d", ft_iterative_factorial(5));
	return 0;
}*/
