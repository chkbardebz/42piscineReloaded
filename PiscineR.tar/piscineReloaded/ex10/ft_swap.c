/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_swap.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: judenis <judenis@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/10/30 15:52:19 by judenis           #+#    #+#             */
/*   Updated: 2023/11/03 15:18:31 by judenis          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_swap(int *a, int *b)
{
	int	temp;

	temp = *a;
	*a = *b;
	*b = temp;
}

/*int main(void)
{
	#include <stdio.h>
	int	a;
	int	b;
	
	a = 2;
	b = 5;
	ft_swap(&a, &b);
	printf("2, 5 : %d, %d", a, b);
	return 0;
}*/
