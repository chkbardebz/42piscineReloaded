/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sqrt.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: judenis <judenis@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/10/30 16:55:18 by judenis           #+#    #+#             */
/*   Updated: 2023/11/03 14:16:09 by judenis          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_sqrt(int nb)
{
	int	i;

	i = 1;
	if (nb < 1)
	{
		return (0);
	}
	while (i * i <= nb)
	{
		if ((i * i) == nb)
			return (i);
		i++;
	}
	return (0);
}

/*int main()
{
	#include <stdio.h>
	printf("brrrrrrrrrrrrrrrrrrrrrrrrrrrrrr\n%d", ft_sqrt(1));
	return 0;
}*/
